﻿function myFunciton() {
    document.getElementById("proba").innerHTML = "stisnuli ste, bravo";

}